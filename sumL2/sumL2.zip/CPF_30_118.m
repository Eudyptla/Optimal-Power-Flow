clear all; close all;
% ====================================================================
% Input the name of the test case
% ====================================================================
%testcase='case30';   %L2sum=0.025837 Lambda=1  max_lam: 2.9859

testcase='case118';   %L2sum = 0.032176 Lambda=1  max_lam: 1.4581

% ====================================================================
% Input the name of the test case
% ====================================================================
define_constants;
mpopt= mpoption('out.all',0,'verbose',2,'cpf.stop_at','FULL','cpf.step',0.1);
mpopt= mpoption(mpopt,'cpf.plot.level',2);
mpcb=loadcase(testcase);
mpct=mpcb;
mpct.gen(:,[PG QG])=mpcb.gen(:,[PG QG])*2.5;
mpct.bus(:,[PD QD])=mpcb.bus(:,[PD QD])*2.5;
results = runcpf(mpcb,mpct,mpopt);
results.cpf
